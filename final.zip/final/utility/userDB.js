//importing the modules
var User = require('../models/user');
var mongoose = require('mongoose');
var meetupdb = 'mongodb://localhost/meetupdb';
var Schema = mongoose.Schema;

//creating a new user model
var userDB = mongoose.model('User', new Schema({
    userID: String,
    firstName: String,
    lastName: String,
    email: String,
    city: String,
    phone: String,
    password: Object
}));

// connecting to mongoose
mongoose.connect(meetupdb, { useNewUrlParser: true, useUnifiedTopology: false });


//creating new user

var createUser = async function(User) {

    var addUser = new userDB({
        userID: User.userID,
        firstName: User.firstName,
        lastName: User.lastName,
        email: User.email,
        city: User.city,
        phone: User.phone,
        password: User.password
    });

    await addUser.save(function(error, addConnection) {
        if (error)
            return console.error(error);
    });

}

//getting user based on usedID
var getUser = async function(userid) {
    var userVal;

    await userDB.findOne({
        userID: userid
    }).exec().then((user) => {

        if (user) {
            userVal = new User.user(user.userID, user.firstName, user.lastName, user.email, user.city, user.phone, user.password);
        }

    }).catch((err) => {
        console.log(err);
    });

    return userVal;
}

// getting all the users
var getUsers = async function() {
    var users_list = [];
    await userDB.find({}).exec().then((user) => {
        users_list = user;
    }).catch((err) => {
        console.log(err);
    });

    return users_list;

};




module.exports.getUsers = getUsers;
module.exports.getUser = getUser;
module.exports.createUser = createUser;