//importing modules
var Connection = require('../models/connection');
var mongoose = require('mongoose'); //importing mongoose 
var Schema = mongoose.Schema; //importing schema from mongoose
var meetupdb = 'mongodb://localhost/meetupdb';

//setting up connectionDB model
var connectionDB = mongoose.model('Connection', new Schema({
    connectionID: String,
    connectionName: String,
    connectionTopic: String,
    venue: String,
    date: String,
    time: String,
    details: String,
    hostedby: String
}));
//connecting to the meetupdb
mongoose.connect(meetupdb, { useNewUrlParser: true, useUnifiedTopology: true });



// getting all the connections
var getConnections = async function() {
    var connection_list = [];
    await connectionDB.find({}).exec().then((co) => {
        connection_list = co;
        console.log(connection_list);
    }).catch((err) => {
        console.log(err);
    });
    return connection_list;

};
// getting a particular connection using connection connectionID
var getConnection = async function(id) {
    var connection;
    var df = String(id);
    await connectionDB.findOne({
        connectionID: df
    }).exec().then((conn) => {
        connection = new Connection.connection(conn.connectionID, conn.connectionName, conn.connectionTopic, conn.venue, conn.date, conn.time, conn.details);
    }).catch((err) => {
        console.log(err);
    });
    return connection;
};

//function for getting list of connections for a user
var getUserConnectionList = async function(id) {
    var userHostedconnections = [];
    await connectionDB.find({
        hostedby: id
    }).exec().then((Obj) => {
        userHostedconnections = Obj;
    }).catch((err) => {
        console.log(err);
    });
    return userHostedconnections;
}


//removing a connection hosted by user using connection ID
var removeUserHostedConnection = async function(connectionId) {
    connectionDB.deleteOne({
        connectionID: connectionId
    }, function(err) {
        if (err) return handleError(err);
    });
}

module.exports.getConnection = getConnection;
module.exports.getConnections = getConnections;
module.exports.connectionDB = connectionDB;
module.exports.getUserConnectionList = getUserConnectionList
module.exports.removeUserHostedConnection = removeUserHostedConnection