//importing the required modules
var mongoose = require('mongoose');
var meetupdb = 'mongodb://localhost/meetupdb';
var Schema = mongoose.Schema;
var Connection = require('./../models/connection');
var newConnectionDB = require('./connectionDB');
var userConnectionDB = mongoose.model('Userconnection', new Schema({
    userID: String,
    connectionId: String,
    connectionName: String,
    rsvp: String,

}));

//connecting to the DB
mongoose.connect(meetupdb, { useNewUrlParser: true, useUnifiedTopology: true });

//getting user profile using userID
var getUserProfile = async function(userId) {
    var user_connections = [];
    await userConnectionDB.find({
        userID: userId
    }).exec().then((userconObj) => {
        user_connections = userconObj;
    }).catch((err) => {
        console.log(err);
    });
    console.log(user_connections);
    return user_connections;
}

//adding RSVP
var add_rsvp = async function(conObj, userId, rsvp) {

    var addUserCon = new userConnectionDB({
        userID: userId,
        connectionId: conObj.connectionID,
        connectionName: conObj.connectionName,
        rsvp: rsvp

    });

    await addUserCon.save(function(err, addedConnection) {
        if (err) return console.error(err);
    });
}

//updating RSVP if already exists

var update_rsvp = async function(connectionId, userId, rsvp) {

    var flag = 1;
    console.log("---" + connectionId + userId + rsvp);
    await userConnectionDB.findOneAndUpdate({ userID: userId, connectionId: connectionId }, { $set: { rsvp: rsvp } }).exec().then((userconnection) => {
        if (userconnection) {
            flag = 0;
        }
    }).catch((err) => {
        console.log(err);

    });

    return flag;
}

//function for deleting a connection based on connectionID and userID
var deleteConnection = async function(connectionId, userId) {
    await userConnectionDB.deleteOne({ userID: userId, connectionId: connectionId }, function(err) {
        if (err) return handleError(err);
    });
}

//addding a new connection
var addNewConnection = async function(connection) {
    var addNewConnection = new newConnectionDB.connectionDB({
        connectionID: connection.connectionID,
        connectionName: connection.connectionName,
        connectionTopic: connection.connectionTopic,
        venue: connection.venue,
        date: connection.date,
        time: connection.time,
        details: connection.details,
        hostedby: connection.hostedby
    });

    await addNewConnection.save(function(err, addedConnection) {
        if (err) return console.error(err);
    });

}


//removing a connection based on Connection ID
var removeUserSavedConnection = async function(connectionId) {
    userConnectionDB.deleteMany({ connectionId: connectionId }, function(err) {
        if (err) return handleError(err);
    });
}



module.exports.getUserProfile = getUserProfile;
module.exports.add_rsvp = add_rsvp;
module.exports.update_rsvp = update_rsvp;
module.exports.deleteConnection = deleteConnection;
module.exports.addNewConnection = addNewConnection;
module.exports.removeUserSavedConnection = removeUserSavedConnection;