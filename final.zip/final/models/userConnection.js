// creating userconnectioin model
var userConnection = function(connection, rsvp) {
    var userConnectionModel = { connection: connection, rsvp: rsvp };

    return userConnectionModel;
};

//exporting userconnection model
module.exports.userConnection = userConnection;