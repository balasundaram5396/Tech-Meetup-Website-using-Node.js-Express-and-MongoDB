//creating user model
var user = function(userID, firstName, lastName, email, city, phone, password) {
    var userModel = { userID: userID, firstName: firstName, lastName: lastName, email: email, city: city, phone: phone, password: password };

    return userModel;
};

//exporting user model
module.exports.user = user;