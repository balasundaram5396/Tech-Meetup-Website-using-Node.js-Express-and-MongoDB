//creating a connection model
var connection = function(connectionID, connectionName, connectionTopic, venue, date, time, details, hostedby) {
    var connectionModel = {
        connectionID: connectionID,
        connectionName: connectionName,
        connectionTopic: connectionTopic,
        venue: venue,
        date: date,
        time: time,
        details: details,
        hostedby: hostedby
    };

    return connectionModel;
};

//exporting the connection model
module.exports.connection = connection;