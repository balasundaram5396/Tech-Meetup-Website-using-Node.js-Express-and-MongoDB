//importing the required packages
var connectionDB = require('./../utility/connectionDB');
var user = require('./user');
var usersConnection = require('./userConnection');
var userConnectionDB = require('./../utility/userConnectionDB');

//userProfile creation
var userProfile = function(userID, userConnection, hostedConnection) {
    this.userID = userID;
    this.userConnection = userConnection;
    this.hostedConnection = hostedConnection

    //adding a connection
    this.addConnection = async function(Connection, rsvp) {
        var userConnectionObject;
        var counter = 1;
        if (this.userConnection.length == 0) {
            userConnectionObject = await connectionDB.getConnection(Connection);
            await userConnectionDB.add_rsvp(userConnectionObject, this.userID, rsvp);
        } else {
            userConnectionObject = await connectionDB.getConnection(Connection);
            counter = await this.updateConnection(new usersConnection.userConnection(userConnectionObject, rsvp));
            if (counter == 1) {
                await userConnectionDB.add_rsvp(userConnectionObject, this.userID, rsvp);

            }

        }
    }



    //removing a connection
    this.removeConnection = async function(ConnectionID) {

        await userConnectionDB.deleteConnection(ConnectionID, this.userID);
    }

    //update a connection
    this.updateConnection = async function(userConnection) {
        var counter = 1;
        console.log(userConnection);
        counter = await userConnectionDB.update_rsvp(userConnection.connection.connectionID, this.userID, userConnection.rsvp);
        return counter;
    }


    // returning list of userConnections of a user
    this.getConnections = async function() {
        this.userConnection = await userConnectionDB.getUserProfile(this.userID);
        return this.userConnection;
    }

    // clearing profile contents
    this.emptyProfile = function() {
        this.userConnection = [];
    }

};



module.exports.userProfile = userProfile;