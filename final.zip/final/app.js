var express = require('express');
var app = express();
app.set('view engine', 'ejs');
app.use('/images', express.static('images'));
app.use('/styles', express.static('styles'));
var router = require('./controllers/connectionController');
var profileController = require('./controllers/profileController');
var session = require('express-session');
app.use(session({ secret: 'abc' }));
//using XSS filtering
var helmet = require('helmet');
app.use(helmet.xssFilter());

//connectionController
app.use('/', router.router);


//profileController
app.use('/myconnections', profileController);

app.get('/*', function(req, res) {
    res.redirect('/');
});

app.listen(8000);
console.log('Listening to port 8000');