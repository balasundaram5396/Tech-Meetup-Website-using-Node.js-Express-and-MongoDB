//importing the packages
var connectionDB = require('../utility/connectionDB');
var userConnectionDB = require('../utility/userConnectionDB');
var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var Connection = require('../models/connection');
var random = require('random-int');
var { check, validationResult } = require('express-validator');
var Regex = require("regex");
var { sanitizeBody } = require('express-validator');
var regex = new Regex(/([12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01]))/);
var regex1 = new Regex(/([12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01]))/);
var { sanitizeBody } = require('express-validator');
var urlEncodedParser = bodyParser.urlencoded({ extended: false });
var helmet = require('helmet')
router.use(helmet.xssFilter());

//ROUTER IMPLEMENTATION

//connection Router
router.get('/connection', async function(request, response) {
    var val;
    if (Object.keys(request.query).length === 0) {
        response.render('connections', { cons: await connectionDB.getConnections(), session: request.session.theUser });
        console.log(connectionDB.getConnections());
    } else if (Object.keys(request.query).length === 1) {
        if (Object.keys(request.query)[0] === 'connectionID') {
            var connectionID = request.query.connectionID;
            val = true;
            if (val) {
                var obj = await connectionDB.getConnection(connectionID)
                if (obj) {
                    response.render('connection', { con: obj, session: request.session.theUser });
                } else {
                    response.render('connections', { cons: await connectionDB.getConnections(), session: request.session.theUser });
                }
            }
        } else {
            response.redirect('/connections');
        }
    }
});

//rendering the home page
router.get('/', function(request, response) {
    response.render('index', { session: request.session.theUser });
});

//rendering the home page
router.get('/index', function(request, response) {
    response.render('index', { session: request.session.theUser });
});

//rendering the about page
router.get('/about', function(request, response) {
    response.render('about', { session: request.session.theUser });
});

//rendering the contact page
router.get('/contact', function(request, response) {
    response.render('contact', { session: request.session.theUser });
});

//rendering the login page
router.get('/login', async function(request, response) {
    response.render('login', { session: request.session.theUser, error: null, page: 'usignin' });

});

//rendering the signup page
router.get('/signup', async function(request, response) {
    response.render('signup', { session: request.session.theUser, err: null });

});

//rendering the connection page
router.get('/connection', function(request, response) {
    response.render('connection');
});

//rendering the connections page
router.get('/connections', async function(request, response) {
    response.render('connections', { cons: await connectionDB.getConnections(), session: request.session.theUser });
});

// add router
router.post('/add', urlEncodedParser, sanitizeBody('notifyOnReply').toBoolean(),
    check('name').custom(value => {
        if (value) {
            if (value.length > 2 && value.length < 40) {
                return /^[a-zA-Z0-9 ]*$/.test(value)
            } else {
                return Promise.reject('Connection Name should have minimum 2 and maximum 40 characters.');
            }
        } else {
            return Promise.reject('Connection name should not be empty');
        }
    }).withMessage('Connection Name should contain only alphabets.'),

    //validating Topic field
    check('topic').custom(value => {
        if (value) {
            if (value.length > 3 && value.length < 100) {
                return /^[a-zA-Z0-9 ]*$/.test(value)
            } else {
                return Promise.reject('Connection topic should have minimum 3 and maximum 100 characters.');
            }
        } else {
            return Promise.reject('Connection topic should not be empty');
        }
    }).withMessage('Connection Topic should contain only alphabets and numbers'),

    //validating Venue field
    check('venue').custom(value => {
        if (value) {
            if (value.length > 2 && value.length < 15) {
                return /^[a-zA-Z ]*$/.test(value)
            } else {
                return Promise.reject('Connection venue should have minimum 2 and maximum 15 characters.');
            }
        } else {
            return Promise.reject('Connection venue should not be empty');
        }
    }).withMessage('Venue should contain only alphabets'),

    //validating Description field
    check('desc').custom(value => {
        if (value) {
            if (value.length > 2 && value.length < 150) {
                return /^[a-zA-Z0-9 ]*$/.test(value)
            } else {
                return Promise.reject('Connection Description should have minimum 2 and maximum 150 characters.');
            }
        } else {
            return Promise.reject('Connection Description should not be empty.');
        }
    }).withMessage('Description should contain only alphabets'),
    async function(request, response) {
        var err = validationResult(request);
        if (!err.isEmpty()) {
            response.render('newConnection', { session: request.session.theUser, error: err.array() });
        } else {

            id = random(150, 900);
            var newConnection = new Connection.connection(id, request.body.name, request.body.topic, request.body.venue, request.body.date, request.body.time, request.body.desc, request.session.theUser.userID);
            await userConnectionDB.addNewConnection(newConnection);
            response.redirect('/connections');
        }
    });


//rendering the newConnection page
router.get('/newConnection', function(request, response) {
    response.render('newConnection', { session: request.session.theUser, error: null });
});

//rendering the savedConnections page
router.get('/savedConnections', function(request, response) {
    response.render('savedConnections', { session: request.session.theUser });
});

module.exports.router = router;