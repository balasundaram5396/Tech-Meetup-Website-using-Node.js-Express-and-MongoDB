//importing the modules
var connectionDB = require('./../utility/connectionDB');
var userConnectionDB = require('./../utility/userConnectionDB');
var UserConnection = require('./../models/UserConnection');
var UserProfile = require('./../models/UserProfile');
var User = require('./../models/user');
var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: false });
var list = require('./../utility/UserDB');
var { sanitizeBody } = require('express-validator');
const { check, validationResult } = require('express-validator');
var ValidatePassword = require('validate-password');
var passwordValidator = require('password-validator');
var pass = new passwordValidator();
var helmet = require('helmet')
router.use(helmet.xssFilter());
var crypto = require('crypto');


//ENCRYPTION AND DECRYPTION

//implementing encryption
var encryption = function(text) {
        const key = crypto.randomBytes(32);
        const iv = crypto.randomBytes(16);
        let cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(key), iv);
        let encrypted = cipher.update(text);
        encrypted = Buffer.concat([encrypted, cipher.final()]);
        return { iv: iv.toString('hex'), encryptedData: encrypted.toString('hex'), key: key };
    }
    //implementing decryption
var decryption = function(text) {
    let iv = Buffer.from(text.iv, 'hex');
    let encrTxt = Buffer.from(text.encryptedData, 'hex');
    let decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(text.key.buffer), iv);
    let decrypted = decipher.update(encrTxt);
    decrypted = Buffer.concat([decrypted, decipher.final()]);
    return decrypted.toString();
}

//setting-up the express validator
pass.is().min(5).is().max(20).has().digits().has().not().spaces();
var options = {
    enforce: {
        lowercase: true,
        uppercase: true,
        specialCharacters: false,
        numbers: true
    }
};
var validator = new ValidatePassword(options);

//creating a empty list and userProfile for holding the list of connections
var connectionList = [];
var connectionID, userProfile;

//ROUTER IMPLEMENTATION

router.get('/', async function(request, response) {
    var all_users = await list.getUsers();
    var user = all_users[0];
    if (request.session.theUser == undefined) {
        request.session.theUser = new User.user(user.userID, user.firstName, user.lastName, user.email, user.city, user.phone, user.password);
    }
    console.log(request.session.theUser);
    userConnectionList = await userConnectionDB.getUserProfile(request.session.theUser.userID);
    var userHostedConnectionList = await connectionDB.getUserConnectionList(request.session.theUser.userID);
    console.log(userHostedConnectionList);
    userProfile = new UserProfile.userProfile(request.session.theUser.userID, userConnectionList, userHostedConnectionList);
    request.session.theUser.userProfile = userProfile;
    response.render('savedConnections', { data: request.session.theUser.userProfile, session: request.session.theUser });
});

//Delete Router
router.get('/delete', async function(request, response) {
    var conID;
    console.log(request.query);
    if (Object.keys(request.query)[0] == 'connectionID') {
        conID = request.query.connectionID;
        await userProfile.removeConnection(conID);
        request.session.theUser.UserProfile = userProfile;
        response.redirect('/myConnections');
    }

})

//Delete Router
router.get('/hostedconnections/delete', async function(request, response) {
    var conID;

    if (Object.keys(request.query)[0] == 'connectionID') {
        conID = request.query.connectionID;
        await connectionDB.removeUserHostedConnection(conID);
        await userConnectionDB.removeUserSavedConnection(conID);
        request.session.theUser.UserProfile = userProfile;
        response.redirect('/myConnections');
    }

})

//Update Router
router.get('/update', async function(request, response) {
    var conID;
    console.log(request.query);
    if (Object.keys(request.query)[0] == 'connectionID') {
        conID = request.query.connectionID;
        response.redirect('/connection?connectionID=' + conID)
    }

});

//RSVP router
router.get('/rsvp', async function(request, response) {
    var connection_ID;
    if (Object.keys(request.query)[0] === 'connectionID') {
        connection_ID = request.query.connectionID;
        await userProfile.addConnection(connection_ID, request.query.rsvp);
        request.session.theUser.userProfile = userProfile;
        response.redirect('/myConnections');
    }
});

//Logout router 
router.get('/signout', function(request, response) {
    request.session.theUser = undefined;
    connectionList = [];
    userProfile = undefined;
    //re-directing to index page
    response.redirect('/');
    //destroying the session
    request.session.destroy();

});

//Login Router
router.post('/login', urlencodedParser, sanitizeBody('notifyOnReply').toBoolean(),
    check('username').isAlphanumeric().withMessage('Enter a valid Username'), check('password').custom(value => {
        if (value != '') {
            if (pass.validate(value) == false) {
                return Promise.reject('Password not valid');
            } else {
                return true;
            }
        } else {
            return Promise.reject('Enter your password');
        }

    }), async function(request, response) {
        var errors = validationResult(request);
        if (!errors.isEmpty()) {
            response.render('login', { session: request.session.theUser, error: errors.array() });
        } else {
            if (request.session.theUser) {
                response.redirect('/myConnections');
            } else {
                var user = await list.getUser(request.body.username);
                if (user) {
                    var dec = await decryption(user.password);

                    if (dec == request.body.password && user.userID == request.body.username) {
                        request.session.theUser = new User.user(user.userID, user.firstName, user.lastName, user.email, user.city, user.phone, user.password);
                        response.redirect('/myConnections');
                    } else {
                        response.render('login', {
                            session: request.session.theUser,
                            error: [{
                                'msg': 'Username or Password Invalid',
                            }],
                            page: 'login'
                        });
                    }
                } else {
                    response.render('login', {
                        session: request.session.theUser,
                        error: [{
                            'msg': 'Username or Password Invalid',
                        }],
                        page: 'login'
                    });
                }
            }
        }

    });

//Signup Router
router.post('/signup', urlencodedParser, sanitizeBody('notifyOnReply').toBoolean(),
    // validating Username field
    check('username').custom(value => {
        if (value) {
            return /^[a-zA-Z0-9]*$/.test(value)
        } else {
            return Promise.reject('Username should not be empty');
        }
    }).withMessage('Username must contain only alphabets and numbers'),
    // Checking whether username already exists
    check('username').custom(async(val, { request }) => {
        if (val) {
            var user = await list.getUser(val);
            if (user) {
                return Promise.reject('Username is already registered');
            } else {
                return true;
            }
        } else {
            return true;
        }
    }),
    //validating firstName
    check('firstName').custom(val => {
        if (val) {
            return /^[a-zA-Z ]*$/.test(val)
        } else {
            return Promise.reject('First Name must not be empty');;
        }
    }).withMessage('First Name must contain only alphabets'),

    //validating Last Name field
    check('lastName').custom(val => {
        if (val) {
            return /^[a-zA-Z ]*$/.test(val)
        } else {
            return Promise.reject('Last Name must not be empty');
        }
    }).withMessage('Last Name must contain only alphabets'),

    //validating E-mail field
    check('email').isEmail().withMessage('Please enter valid email id'),
    check('city').custom(val => {
        if (val) {
            return /^[a-zA-Z ]*$/.test(val)
        } else {
            return Promise.reject('City must not be empty');
        }
    }).withMessage('City must contain only alphabets'),

    //validating Phone field
    check('phone').custom(val => {
        if (val) {
            return /^[0-9]*$/.test(val)
        } else {
            return Promise.reject('Phone number must not be empty');
        }
    }).withMessage('Phone number must contain only alphabets'),

    //validating  password entry
    check('password').custom(val => {
        var validate = pass.validate(val);
        if (val == '') {
            return Promise.reject('Please enter your new password');
        } else if (validate == false) {
            return Promise.reject('Password is not valid');
        } else {
            return true;
        }
    }),
    async function(request, response) {
        var errors = await validationResult(request);
        console.log(errors);
        if (!errors.isEmpty()) {
            response.render('signup', { session: request.session.theUser, err: errors.array() });
        } else {
            var password = await encryption(request.body.password);
            var newUser = new User.user(request.body.username, request.body.firstName, request.body.lastName, request.body.email, request.body.city, request.body.phone, password);
            await list.createUser(newUser);
            response.render('login', { session: request.session.theUser, error: errors.array() });
        }
    });



module.exports = router;